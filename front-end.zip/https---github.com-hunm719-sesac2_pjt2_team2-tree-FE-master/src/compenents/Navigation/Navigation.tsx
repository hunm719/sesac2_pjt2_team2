import React, { useState } from "react";
import { BottomNavigation, BottomNavigationAction, Box } from "@mui/material";
import { Home, Edit, FileText, User } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Navigation: React.FC = () => {
  const [currentTab, setCurrentTab] = useState("home");
  const navigate = useNavigate();

  const handleNavigation = (value: string) => {
    setCurrentTab(value);
    navigate(value === "home" ? "/" : `/${value}`);
  };

  return (
    <Box
      sx={{
        position: "fixed",
        bottom: 0,
        left: 0,
        right: 0,
        backgroundColor: "#fff",
        borderTop: "1px solid #ddd",
      }}
    >
      <BottomNavigation
        value={currentTab}
        onChange={(event, newValue) => handleNavigation(newValue)}
        showLabels
      >
        <BottomNavigationAction value="home" icon={<Home size={30} />} />
        <BottomNavigationAction value="board" icon={<FileText size={30} />} />
        <BottomNavigationAction value="create" icon={<Edit size={30} />} />
        <BottomNavigationAction value="profile" icon={<User size={30} />} />
      </BottomNavigation>
    </Box>
  );
};

export default Navigation;
