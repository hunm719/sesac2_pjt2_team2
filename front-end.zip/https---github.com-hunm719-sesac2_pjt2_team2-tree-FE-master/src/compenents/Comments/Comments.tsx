import React, { useState, useEffect } from "react";
import {
  TextField,
  Button,
  Box,
  List,
  ListItem,
  Typography,
} from "@mui/material";
import { MessageSquareDiff } from "lucide-react"; // Import icon from lucide-react

interface CommentsProps {
  postId: string;
}

export default function Comments({ postId }: CommentsProps) {
  const [comment, setComment] = useState("");
  const [commentList, setCommentList] = useState<string[]>([]);

  useEffect(() => {
    const fetchComments = async () => {
      const response = await fetch(`/api/posts/${postId}/comments`);
      const data = await response.json();
      setCommentList(data);
    };

    fetchComments();
  }, [postId]);

  const handleCommentSubmit = async () => {
    if (comment.trim()) {
      setCommentList([...commentList, comment]);
      setComment("");

      await fetch(`/api/posts/${postId}/comments`, {
        method: "POST",
        body: JSON.stringify({ comment }),
        headers: { "Content-Type": "application/json" },
      });
    }
  };

  return (
    <Box sx={{ marginTop: 2 }}>
      {/* 댓글 입력 필드 */}
      <TextField
        label="댓글을 작성하세요"
        variant="outlined"
        fullWidth
        value={comment}
        onChange={(e) => setComment(e.target.value)}
        sx={{ marginBottom: 2 }}
      />
      <Button
        variant="contained"
        color="primary"
        onClick={handleCommentSubmit}
        sx={{ display: "flex", alignItems: "center" }}
      >
        <MessageSquareDiff size={20} style={{ marginRight: 8 }} /> 댓글 작성
      </Button>

      <List sx={{ marginTop: 2 }}>
        {commentList.map((comment, index) => (
          <ListItem key={index}>
            <Typography variant="body2" color="text.secondary">
              {comment}
            </Typography>
          </ListItem>
        ))}
      </List>
    </Box>
  );
}
