import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardMedia,
  Typography,
  Box,
  Button,
  Chip,
} from "@mui/material";
import { formatDistanceToNow } from "date-fns";
import { Heart, MessageSquare } from "lucide-react";
import { Post } from "../../types/Post";
import "./Posts.css";

interface PostsProps {
  post: Post;
}

export default function PostCard({ post }: PostsProps) {
  const [likes, setLikes] = useState(post.likes);
  const [isLiked, setIsLiked] = useState(false);
  const navigate = useNavigate();

  const handleLikeClick = () => {
    setLikes(isLiked ? likes - 1 : likes + 1);
    setIsLiked(!isLiked);
  };

  const handleImageClick = () => {
    navigate(`/board/${post.id}`);
  };

  return (
    <Card className="post-card">
      <CardMedia className="post-card-media" image={post.imgUrl} />
      <CardContent>
        <Box className="post-card-header">
          <Typography
            variant="subtitle1"
            className="post-card-user"
            onClick={handleImageClick}
          >
            {post.user_id}
          </Typography>
          <Typography variant="caption" className="post-card-time">
            {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
          </Typography>
        </Box>
        <Typography variant="body1" className="post-card-title">
          {post.title}
        </Typography>
        <Typography variant="body2" className="post-card-description">
          {post.description}
        </Typography>

        <Box className="post-card-footer">
          <Button className="post-card-button" onClick={handleLikeClick}>
            <Heart
              size={20}
              className={isLiked ? "post-card-heart liked" : "post-card-heart"}
            />
            {likes}
          </Button>
          <Button className="post-card-button">
            <MessageSquare size={20} className="post-card-comment-icon" />
            {post.comments.length}
          </Button>
        </Box>

        <Box className="post-card-tags" sx={{ mt: 1, display: "flex", gap: 1 }}>
          {post.tags.map((tag, index) => (
            <Chip
              key={index}
              label={`#${tag}`}
              size="small"
              color="primary"
              className="post-card-tag"
              sx={{
                backgroundColor: "#78B7D0",
                color: "#fff",
              }}
            />
          ))}
        </Box>
      </CardContent>
    </Card>
  );
}
