import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Box, Typography, IconButton } from "@mui/material";
import { ChevronLeft } from "lucide-react";

const Header = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const showBackButton = location.pathname !== "/";

  const handleBack = () => {
    navigate("/");
  };

  const getPageTitle = () => {
    switch (location.pathname) {
      case "/board":
        return "게시판";
      case "/create":
        return "새 게시물 작성";
      case "/profile":
        return "프로필";
      default:
        return "나이쁘개🌼";
    }
  };

  return (
    <Box sx={{ padding: 2, display: "flex", alignItems: "center" }}>
      {showBackButton && (
        <IconButton onClick={handleBack} sx={{ marginRight: 2 }}>
          <ChevronLeft />
        </IconButton>
      )}
      <Typography variant="h6">{getPageTitle()}</Typography>
    </Box>
  );
};

export default Header;
