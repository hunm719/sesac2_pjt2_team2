import { ImagePlus, CirclePlus } from "lucide-react";
import React, { useState } from "react";
import { Button, TextField, Box, Snackbar, Chip } from "@mui/material";
import { useNavigate } from "react-router-dom";

export default function CreatePost() {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [image, setImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [tagInput, setTagInput] = useState("");
  const [tags, setTags] = useState<string[]>([]);
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");

  const navigate = useNavigate();

  const user = {
    username: "user123",
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files ? e.target.files[0] : null;
    if (file) {
      setImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleTagAdd = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput("");
    }
  };

  const handleTagRemove = (tagToRemove: string) => {
    setTags(tags.filter((tag) => tag !== tagToRemove));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    setSnackbarMessage("게시물이 성공적으로 작성되었습니다!");
    setOpenSnackbar(true);

    console.log("게시물 작성:", { title, content, image, tags, user });

    // 3초 후 게시판 페이지로 리디렉션
    setTimeout(() => {
      navigate("/board");
    }, 3000);
  };

  return (
    <Box
      sx={{
        padding: 3,
        maxWidth: 600,
        margin: "0 auto",
        backgroundColor: "#f7f7f7",
        borderRadius: "12px",
        overflowY: "auto",
        maxHeight: "calc(100vh - 50px)",
      }}
    >
      <TextField
        label="제목"
        variant="outlined"
        fullWidth
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        sx={{
          marginBottom: 2,
          backgroundColor: "#ffffff",
          borderRadius: "8px",
        }}
      />

      <TextField
        label="내용"
        variant="outlined"
        multiline
        rows={4}
        fullWidth
        value={content}
        onChange={(e) => setContent(e.target.value)}
        sx={{
          marginBottom: 2,
          backgroundColor: "#ffffff",
          borderRadius: "8px",
        }}
      />

      {imagePreview && (
        <Box sx={{ marginBottom: 2 }}>
          <img
            src={imagePreview}
            alt="Preview"
            style={{
              width: "100%",
              height: "auto",
              borderRadius: "8px",
              boxShadow: "0px 4px 12px rgba(0, 0, 0, 0.1)",
            }}
          />
        </Box>
      )}
      <input
        type="file"
        accept="image/*"
        onChange={handleImageChange}
        style={{ display: "none" }}
        id="image-upload"
      />
      <label htmlFor="image-upload">
        <Button
          variant="outlined"
          component="span"
          sx={{
            marginBottom: 2,
            backgroundColor: "#E1D7C6",
            color: "#fff",
            borderRadius: "8px",
            display: "flex",
            alignItems: "center",
            gap: 1,
          }}
        >
          <ImagePlus size={20} />
        </Button>
      </label>

      <Box
        sx={{ display: "flex", gap: 1, alignItems: "center", marginBottom: 2 }}
      >
        <TextField
          label="태그 입력"
          variant="outlined"
          value={tagInput}
          onChange={(e) => setTagInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleTagAdd()}
          sx={{
            flex: 1,
            backgroundColor: "#ffffff",
            borderRadius: "8px",
          }}
        />
        <Button
          variant="contained"
          onClick={handleTagAdd}
          sx={{
            backgroundColor: "#ffb6b9",
            color: "#fff",
            borderRadius: "8px",
            display: "flex",
            alignItems: "center",
            gap: 1,
          }}
        >
          <CirclePlus size={20} />
        </Button>
      </Box>

      <Box sx={{ display: "flex", gap: 1, flexWrap: "wrap", marginBottom: 2 }}>
        {tags.map((tag, index) => (
          <Chip
            key={index}
            label={`#${tag}`}
            onDelete={() => handleTagRemove(tag)}
            color="primary"
            sx={{ backgroundColor: "#ffb6b9" }}
          />
        ))}
      </Box>

      <Button
        variant="contained"
        onClick={handleSubmit}
        fullWidth
        sx={{
          backgroundColor: "#78B7D0",
          color: "#fff",
          borderRadius: "8px",
        }}
      >
        게시물 등록
      </Button>

      <Snackbar
        open={openSnackbar}
        autoHideDuration={3000}
        onClose={() => setOpenSnackbar(false)}
        message={snackbarMessage}
      />
    </Box>
  );
}
