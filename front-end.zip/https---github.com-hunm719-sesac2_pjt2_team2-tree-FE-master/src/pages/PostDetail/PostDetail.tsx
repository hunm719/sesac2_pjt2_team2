import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

const sampleData = [
  {
    id: "1",
    user_id: "user123",
    createdAt: "2024-11-26T09:00:00+09:00",
    title: "샘플 게시물 1",
    description: "우리 고양이의 하루 루틴을 공유합니다. 귀여움 주의!",
    imgUrl:
      "https://cdn.pixabay.com/photo/2016/12/13/05/15/puppy-1903313_640.jpg",
    likes: 10,
    comments: ["정말 멋진 글이에요!", "내용이 정말 유익하네요."],
  },
  {
    id: "2",
    user_id: "user456",
    createdAt: "2024-11-26T09:00:00+09:00",
    title: "샘플 게시물 2",
    description: "맛있는 파스타를 집에서 간단히 만드는 방법을 소개합니다.",
    imgUrl:
      "https://cdn.pixabay.com/photo/2020/03/31/19/20/dog-4988985_640.jpg",
    likes: 305,
    comments: ["좋은 작업이에요!", "여기서 많은 것을 배웠습니다."],
  },
  {
    id: "3",
    user_id: "doglover99",
    createdAt: "2024-11-25T12:30:00+09:00",
    title: "강아지와 산책 팁",
    description: "강아지와의 산책이 즐거워지는 꿀팁을 공유합니다.",
    imgUrl:
      "https://cdn.pixabay.com/photo/2020/11/08/10/25/dog-5723334_640.jpg",
    likes: 515,
    comments: ["이 팁 너무 좋아요!", "강아지 키우는 사람들에게 강추합니다."],
  },
  {
    id: "4",
    user_id: "catfan12",
    createdAt: "2024-11-24T08:00:00+09:00",
    title: "고양이의 하루 루틴",
    description: "우리 고양이의 하루 루틴을 공유합니다. 귀여움 주의!",
    imgUrl:
      "https://cdn.pixabay.com/photo/2016/12/13/05/15/puppy-1903313_640.jpg",
    likes: 38,
    comments: ["고양이가 너무 귀엽네요!", "사진이 있으면 더 좋았을 것 같아요."],
  },
  {
    id: "6",
    user_id: "foodie_amy",
    createdAt: "2024-11-22T15:45:00+09:00",
    title: "집에서 만드는 쉬운 파스타 레시피",
    description: "맛있는 파스타를 집에서 간단히 만드는 방법을 소개합니다.",
    imgUrl: "https://via.placeholder.com/150",
    likes: 20,
    comments: [
      "바로 만들어 봤는데 너무 맛있어요!",
      "저도 이 레시피로 해볼게요.",
    ],
  },
  {
    id: "7",
    user_id: "tech_guy",
    createdAt: "2024-11-21T18:00:00+09:00",
    title: "최신 IT 트렌드 요약",
    description: "최근 IT 업계에서 주목받는 기술 트렌드를 요약했습니다.",
    imgUrl: "https://via.placeholder.com/150",
    likes: 18,
    comments: ["유익한 정보 감사합니다!", "이 기술을 더 공부해봐야겠어요."],
  },
];

const PostDetail = () => {
  const { postId } = useParams<{ postId: string }>();
  const [post, setPost] = useState<any>(null);

  useEffect(() => {
    const foundPost = sampleData.find((post) => post.id === postId);
    setPost(foundPost);
  }, [postId]);

  if (!post) {
    return <p>Loading...</p>;
  }

  return (
    <div>
      <h1>{post.title}</h1>
      <img src={post.imgUrl} alt={post.title} />
      <p>{post.description}</p>
      <p>{post.likes} likes</p>
      <p>{post.comments.length} comments</p>
      <div>
        <h3>Comments</h3>
        <ul>
          {post.comments.map((comment: string, index: number) => (
            <li key={index}>{comment}</li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default PostDetail;
