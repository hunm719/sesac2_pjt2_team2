import React, { useEffect, useState } from "react";
import { Typography, TextField } from "@mui/material";
import { useNavigate } from "react-router-dom";
import "./Profile.css";

export default function Profile() {
  const [user, setUser] = useState<any>(null);
  const [error, setError] = useState<string>("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem("access_token");

    if (token) {
      fetchUserProfile(token);
    }
  }, []);

  const fetchUserProfile = async (token: string) => {
    try {
      const response = await fetch("/api/profile", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error("프로필 정보를 가져오는 데 실패했습니다.");
      }

      const data = await response.json();
      setUser(data);
    } catch (error) {
      setError("로그인 오류가 발생했습니다.");
    }
  };

  const handleLogin = async () => {
    if (!username || !password) {
      setError("아이디와 비밀번호를 입력하세요.");
      return;
    }
    const token = "example_jwt_token"; // 예시 토큰
    localStorage.setItem("access_token", token);
    fetchUserProfile(token);
  };

  const handleSignUp = () => {
    navigate("/signup");
  };

  const renderLoginForm = () => (
    <div className="login-container">
      <TextField
        label="아이디"
        variant="outlined"
        fullWidth
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        className="input-field"
      />
      <TextField
        label="비밀번호"
        type="password"
        variant="outlined"
        fullWidth
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        className="input-field"
      />
      <button className="login-button" onClick={handleLogin}>
        로그인
      </button>

      <div className="or-container">
        <div className="or-line"></div>
        <span className="or-text">or</span>
        <div className="or-line"></div>
      </div>

      <button className="signup-button" onClick={handleSignUp}>
        회원가입
      </button>
    </div>
  );

  if (error) {
    return (
      <div className="error-container">
        <Typography variant="h6" color="error">
          {error}
        </Typography>
      </div>
    );
  }

  if (!user) {
    return renderLoginForm();
  }

  return (
    <div className="profile-container">
      <Typography variant="h5" gutterBottom>
        {user.username}님의 프로필
      </Typography>

      <div className="profile-details">
        {user.avatar && (
          <img src={user.avatar} alt="User Avatar" className="avatar" />
        )}
        <Typography variant="h6">이메일: {user.email}</Typography>
        <Typography variant="h6">아이디: {user.username}</Typography>
      </div>

      <div className="post-list">
        <Typography variant="h6" gutterBottom>
          내가 쓴 게시물
        </Typography>
        <ul>
          {user.posts?.length > 0 ? (
            user.posts.map((post: any) => (
              <li key={post.id}>
                <Typography variant="body1">{post.title}</Typography>
              </li>
            ))
          ) : (
            <Typography variant="body1">작성한 게시물이 없습니다.</Typography>
          )}
        </ul>
      </div>
    </div>
  );
}
