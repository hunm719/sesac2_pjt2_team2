import React, { useState, useEffect } from "react";
import { Box, Typography } from "@mui/material";
import { Grid } from "@mui/system";
import { Post } from "../../types/Post";
import Posts from "../../compenents/Posts/Posts";
import postData from "../../sampleData/posts.json";

export default function Board() {
  const [posts, setPosts] = useState<Post[]>([]);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        setPosts(postData as Post[]);
      } catch (error) {
        console.error("Error loading posts:", error);
      }
    };
    fetchPosts();
  }, []);

  return (
    <Box sx={{ padding: 3 }}>
      <Grid container spacing={3}>
        {posts.length > 0 ? (
          posts.map((post) => (
            <Grid>
              {" "}
              {/* Grid item 추가 */}
              <Posts post={post} />
            </Grid>
          ))
        ) : (
          <Typography variant="body1">로딩중...</Typography>
        )}
      </Grid>
    </Box>
  );
}
