import React, { useState } from "react";
import { Box, Typography } from "@mui/material";
import Post from "../../compenents/Posts/Posts";
import "./Home.css";

import postData from "../../sampleData/posts.json";

const Home: React.FC = () => {
  const [posts, setPosts] = useState(postData);

  const topLikedPost = [...posts].sort((a, b) => b.likes - a.likes)[0];

  return (
    <Box className="home-container">
      <Box className="section">
        <span className="section-title"> 이번 주 인기 🐕</span>
        {topLikedPost && <Post post={topLikedPost} />}
      </Box>

      <Box className="section">
        <span className="section-title">🐕지트</span>
        <Box className="horizontal-scroll">
          {posts.map((post) => (
            <Box key={post.id} className="post-preview">
              <img
                src={post.imgUrl}
                alt={post.title}
                className="post-preview-image"
              />
              <Typography variant="subtitle1" className="post-preview-title">
                {post.title}
              </Typography>
              <Typography variant="body2" className="post-preview-user">
                {post.user_id}
              </Typography>
            </Box>
          ))}
        </Box>
      </Box>
    </Box>
  );
};

export default Home;
