export type Post = {
  id: string;
  user_id: string;
  createdAt: string;
  title: string;
  description: string;
  imgUrl: string;
  likes: number;
  comments: {
    user_id: string;
    content: string;
    createdAt: string;
  }[];
  tags: string[];
};
