import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navigation from "./compenents/Navigation/Navigation";
import Home from "./pages/Home/Home";
import Board from "./pages/Board/Board";
import CreatePost from "./pages/CreatePost/CreatePost";
import Profile from "./pages/Profile/Profile";
import PostDetail from "./pages/PostDetail/PostDetail";
import Header from "./compenents/Header/Header";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import { CssBaseline } from "@mui/material";
import "./App.css";

const theme = createTheme({
  typography: {
    fontFamily: "GowunDodum-Regular",
  },
});

function App() {
  return (
    <>
      <ThemeProvider theme={theme}>
        <CssBaseline />

        <Router>
          <div className="app-container">
            <Header />

            <div className="content">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/board" element={<Board />} />
                <Route path="/create" element={<CreatePost />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/board/:postId" element={<PostDetail />} />
              </Routes>
            </div>

            <Navigation />
          </div>
        </Router>
      </ThemeProvider>
    </>
  );
}

export default App;
